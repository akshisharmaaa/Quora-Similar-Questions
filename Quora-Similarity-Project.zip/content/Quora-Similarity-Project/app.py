
import pickle
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
import gradio as gr

# Load data
index = faiss.read_index("faiss_index.idx")
embeddings = np.load("question_embeddings.npy")
with open("questions.pkl", "rb") as f:
    questions = pickle.load(f)

# Load model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Search function
def search_similar(query):
    query_emb = model.encode([query])
    D, I = index.search(query_emb, 5)
    results = [f"→ {questions[i]} (distance: {D[0][k]:.4f})" for k, i in enumerate(I[0])]
    return "\n".join(results)

# Gradio app
iface = gr.Interface(fn=search_similar,
                     inputs=gr.Textbox(label="Ask a question"),
                     outputs="text",
                     title="Semantic Question Finder (Quora)",
                     description="Finds similar questions using embeddings and FAISS")

iface.launch()
